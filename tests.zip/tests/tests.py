import unittest
from flask import Flask
from flask_testing import TestCase
from your_app import app, db, User, Issue, Commit, analyze_repository

# Set the testing configuration
app.config['TESTING'] = True
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'  # Use an in-memory database for testing
app.config['WTF_CSRF_ENABLED'] = False  # Disable CSRF protection in forms for testing

class YourAppTestCase(TestCase):

    def create_app(self):
        return app

    def setUp(self):
        db.create_all()

    def tearDown(self):
        db.session.remove()
        db.drop_all()

    def test_login_successful(self):
        response = self.client.post('/login', data=dict(
            email='test@example.com',
            password='testpassword'
        ), follow_redirects=True)
        self.assertIn(b'Logged in successfully!', response.data)

    def test_login_invalid_credentials(self):
        response = self.client.post('/login', data=dict(
            email='invalid@example.com',
            password='wrongpassword'
        ), follow_redirects=True)
        self.assertIn(b'Please enter correct email/password!', response.data)

    def test_register_successful(self):
        response = self.client.post('/register', data=dict(
            name='New User',
            email='newuser@example.com',
            password='newpassword'
        ), follow_redirects=True)
        self.assertIn(b'You have successfully registered!', response.data)

    def test_register_existing_user(self):
        # Add a user to the database
        existing_user = User(name='Existing User', email='existing@example.com', password='existingpassword')
        db.session.add(existing_user)
        db.session.commit()

        # Try to register with the same email
        response = self.client.post('/register', data=dict(
            name='New User',
            email='existing@example.com',
            password='newpassword'
        ), follow_redirects=True)
        self.assertIn(b'Account already exists!', response.data)

    def test_analyze_repository(self):
        # Mock the subprocess.run and check_output functions
        def mock_subprocess_run(*args, **kwargs):
            pass

        def mock_subprocess_check_output(command, *args, **kwargs):
            if 'git clone' in command:
                return b''
            elif 'git log' in command:
                return b'commit_hash,Fixing a bug\n'

        subprocess.run = mock_subprocess_run
        subprocess.check_output = mock_subprocess_check_output

        # Create a test repository
        repo_url = 'https://github.com/example/test-repo.git'

        # Analyze the repository
        result = analyze_repository(repo_url)

        # Check if the expected values are in the result
        self.assertIsInstance(result, dict)
        self.assertIn('commit_count', result)
        self.assertIn('latest_commit_hash', result)
        self.assertIn('latest_commit_message', result)
        self.assertIn('commits', result)

        # Reset subprocess functions to their original implementations
        subprocess.run = original_run
        subprocess.check_output = original_check_output

if __name__ == '__main__':
    unittest.main()
