function getBotResponse(input) {
    //rock paper scissors
    if (input == "rock") {
        return "paper";
    } else if (input == "paper") {
        return "scissors";
    } else if (input == "scissors") {
        return "rock";
    }

    // Simple responses
    if (input == "hello","hi","yoo","ssup") {
        return "Hello there!";
    } 
    else if (input == "what services are you offering") {
        return "we offer git tracking services for free";
    } 
    else if (input == "prices","accounts") {
        return "we offer services for free so no need to worry";
    }
    else if (input == "what exactly are the services") {
        return "we track your commits and show the outputs";
    }else if (input == "goodbye") {
        return "Talk to you later!";
    }
    
    
    
    
    
    else {
        return "Try asking something else!";
    }
}